# <plugin name>

## Description

Describe what the plugin does (what is it good for?)

## Support

If a support forum or thread exists, describe it and add a link to it in this section

## Version / Change History

If you want, enter the change history here

## Requirements

What other software or what hardware ist needed to use the plugin

## Configuration

### plugin.yaml

#### Parameters

#### Example plugin configuration

### items.yaml

#### Attributes

#### Example item configuration

### logic.yaml

## Functions